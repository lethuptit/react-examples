## ravenous

A client-side React application, utilizing the Yelp API to search for local businesses.